package com.chinook;

import com.chinook.util.PasswordUtil;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PasswordUtilTest {

    @Test
    void testHashIsNotPlainText() {
        String hash = PasswordUtil.hash("mypassword");
        assertNotEquals("mypassword", hash);
    }

    @Test
    void testVerifyCorrectPassword() {
        String hash = PasswordUtil.hash("secret123");
        assertTrue(PasswordUtil.verify("secret123", hash));
    }

    @Test
    void testVerifyWrongPassword() {
        String hash = PasswordUtil.hash("correct");
        assertFalse(PasswordUtil.verify("wrong", hash));
    }
}