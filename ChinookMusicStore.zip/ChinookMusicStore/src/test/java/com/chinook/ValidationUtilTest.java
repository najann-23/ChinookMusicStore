package com.chinook;

import com.chinook.util.ValidationUtil;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ValidationUtilTest {

    @Test
    void testNullIsEmpty() {
        assertTrue(ValidationUtil.isNullOrEmpty(null));
    }

    @Test
    void testBlankIsEmpty() {
        assertTrue(ValidationUtil.isNullOrEmpty("   "));
    }

    @Test
    void testValidEmail() {
        assertTrue(ValidationUtil.isValidEmail("test@example.com"));
    }

    @Test
    void testInvalidEmail() {
        assertFalse(ValidationUtil.isValidEmail("not-an-email"));
    }

    @Test
    void testPositiveValue() {
        assertTrue(ValidationUtil.isPositive(5.0));
        assertFalse(ValidationUtil.isPositive(-1.0));
    }
}