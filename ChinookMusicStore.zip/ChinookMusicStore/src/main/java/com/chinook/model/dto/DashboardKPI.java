package com.chinook.model.dto;

public class DashboardKPI{
    int totalTracks;
    int totalCustomers;
    int totalInvoices;
    double totalRevenue;
    String topCountry;
}