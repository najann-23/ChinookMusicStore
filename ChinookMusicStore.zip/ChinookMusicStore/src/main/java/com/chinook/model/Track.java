package com.chinook.model;

import java.math.BigDecimal;

public class Track {
    private int trackId;
    private String name;
    private int albumId;
    private String composer;
    private int milliseconds;
    private BigDecimal unitPrice;

    public Track() {}

    public Track(int trackId, String name, int albumId,
                 String composer, int milliseconds, BigDecimal unitPrice) {
        this.trackId = trackId;
        this.name = name;
        this.albumId = albumId;
        this.composer = composer;
        this.milliseconds = milliseconds;
        this.unitPrice = unitPrice;
    }

    public int getTrackId() { return trackId; }
    public void setTrackId(int trackId) { this.trackId = trackId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getAlbumId() { return albumId; }
    public void setAlbumId(int albumId) { this.albumId = albumId; }
    public String getComposer() { return composer; }
    public void setComposer(String composer) { this.composer = composer; }
    public int getMilliseconds() { return milliseconds; }
    public void setMilliseconds(int milliseconds) { this.milliseconds = milliseconds; }
    public BigDecimal getUnitPrice() { return unitPrice; }
    public void setUnitPrice(BigDecimal unitPrice) { this.unitPrice = unitPrice; }
}