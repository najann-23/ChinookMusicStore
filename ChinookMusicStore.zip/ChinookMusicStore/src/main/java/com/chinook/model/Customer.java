package com.chinook.model;

public class Customer {
    private int customerId;
    private String firstName;
    private String lastName;
    private String email;
    private String country;

    public Customer() {}

    public Customer(int customerId, String firstName,
                    String lastName, String email, String country) {
        this.customerId = customerId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.country = country;
    }

    public int getCustomerId() { return customerId; }
    public void setCustomerId(int id) { this.customerId = id; }
    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }

    public String getFullName() { return firstName + " " + lastName; }
}