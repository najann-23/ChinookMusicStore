package com.chinook.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Invoice {
    private int invoiceId;
    private int customerId;
    private LocalDate invoiceDate;
    private String billingCountry;
    private BigDecimal total;

    public Invoice() {}

    public Invoice(int invoiceId, int customerId, LocalDate invoiceDate,
                   String billingCountry, BigDecimal total) {
        this.invoiceId = invoiceId;
        this.customerId = customerId;
        this.invoiceDate = invoiceDate;
        this.billingCountry = billingCountry;
        this.total = total;
    }

    public int getInvoiceId() { return invoiceId; }
    public void setInvoiceId(int invoiceId) { this.invoiceId = invoiceId; }
    public int getCustomerId() { return customerId; }
    public void setCustomerId(int customerId) { this.customerId = customerId; }
    public LocalDate getInvoiceDate() { return invoiceDate; }
    public void setInvoiceDate(LocalDate invoiceDate) { this.invoiceDate = invoiceDate; }
    public String getBillingCountry() { return billingCountry; }
    public void setBillingCountry(String billingCountry) { this.billingCountry = billingCountry; }
    public BigDecimal getTotal() { return total; }
    public void setTotal(BigDecimal total) { this.total = total; }
}