package com.chinook.controller;

import com.chinook.model.User;
import javax.swing.*;

public class RoleGuard {
    private static User currentUser;

    public static void setCurrentUser(User u) { currentUser = u; }
    public static User getCurrentUser() { return currentUser; }

    public static boolean isAdmin() {
        return currentUser != null && currentUser.isAdmin();
    }

    public static void applyTo(JButton btn) {
        btn.setVisible(isAdmin());
        btn.setEnabled(isAdmin());
    }
}