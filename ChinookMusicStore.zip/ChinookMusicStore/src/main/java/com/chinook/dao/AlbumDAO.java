package com.chinook.dao;

import com.chinook.model.Album;
import java.sql.*;
import java.util.*;

public class AlbumDAO extends AbstractDAO implements BaseDAO<Album> {

    @Override
    public Optional<Album> findById(int id) {
        String sql = "SELECT * FROM Album WHERE AlbumId = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return Optional.of(new Album(
                    rs.getInt("AlbumId"),
                    rs.getString("Title"),
                    rs.getInt("ArtistId")));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return Optional.empty();
    }

    @Override
    public List<Album> findAll() {
        List<Album> list = new ArrayList<>();
        String sql = "SELECT * FROM Album ORDER BY Title";
        try (Statement st = getConnection().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new Album(
                    rs.getInt("AlbumId"),
                    rs.getString("Title"),
                    rs.getInt("ArtistId")));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    @Override
    public List<Album> findAll(int page, int pageSize) {
        List<Album> list = new ArrayList<>();
        String sql = "SELECT * FROM Album ORDER BY Title LIMIT ? OFFSET ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setInt(1, pageSize);
            ps.setInt(2, (page - 1) * pageSize);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Album(rs.getInt("AlbumId"), rs.getString("Title"), rs.getInt("ArtistId")));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    @Override
    public boolean save(Album album) {
        String sql = "INSERT INTO Album (Title, ArtistId) VALUES (?, ?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setString(1, album.getTitle());
            ps.setInt(2, album.getArtistId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    @Override
    public boolean update(Album album) {
        String sql = "UPDATE Album SET Title = ?, ArtistId = ? WHERE AlbumId = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setString(1, album.getTitle());
            ps.setInt(2, album.getArtistId());
            ps.setInt(3, album.getAlbumId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    @Override
    public boolean delete(int id) {
        String sql = "DELETE FROM Album WHERE AlbumId = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public List<Album> findByArtist(int artistId) {
        List<Album> list = new ArrayList<>();
        String sql = "SELECT * FROM Album WHERE ArtistId = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setInt(1, artistId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Album(rs.getInt("AlbumId"), rs.getString("Title"), rs.getInt("ArtistId")));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }
}