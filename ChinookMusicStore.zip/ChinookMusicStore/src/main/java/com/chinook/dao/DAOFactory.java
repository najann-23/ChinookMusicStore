package com.chinook.dao;

public class DAOFactory {

    public static ArtistDAO createArtistDAO()     { return new ArtistDAO(); }
    public static AlbumDAO createAlbumDAO()       { return new AlbumDAO(); }
    public static CustomerDAO createCustomerDAO() { return new CustomerDAO(); }
    public static InvoiceDAO createInvoiceDAO()   { return new InvoiceDAO(); }
    public static UserDAO createUserDAO()         { return new UserDAO(); }
}