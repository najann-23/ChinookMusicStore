package com.chinook.dao;

import com.chinook.util.DatabaseConnection;
import java.sql.Connection;

public abstract class AbstractDAO {
    protected Connection getConnection() {
        return DatabaseConnection.getInstance().getConnection();
    }
}