package com.chinook.dao;

import java.sql.Date;        
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import com.chinook.model.Invoice;
import java.time.LocalDate;
import java.util.*;

public class InvoiceDAO extends AbstractDAO implements BaseDAO<Invoice> {

    private Invoice mapRow(ResultSet rs) throws SQLException {
        return new Invoice(
            rs.getInt("InvoiceId"),
            rs.getInt("CustomerId"),
            rs.getDate("InvoiceDate").toLocalDate(),
            rs.getString("BillingCountry"),
            rs.getBigDecimal("Total"));
    }

    @Override
    public Optional<Invoice> findById(int id) {
        String sql = "SELECT * FROM Invoice WHERE InvoiceId = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return Optional.of(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return Optional.empty();
    }

    @Override
    public List<Invoice> findAll() {
        List<Invoice> list = new ArrayList<>();
        try (Statement st = getConnection().createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM Invoice ORDER BY InvoiceDate DESC")) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    @Override
    public List<Invoice> findAll(int page, int pageSize) {
        List<Invoice> list = new ArrayList<>();
        String sql = "SELECT * FROM Invoice ORDER BY InvoiceDate DESC LIMIT ? OFFSET ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setInt(1, pageSize);
            ps.setInt(2, (page - 1) * pageSize);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    @Override
    public boolean save(Invoice inv) {
        String sql = "INSERT INTO Invoice (CustomerId,InvoiceDate,BillingCountry,Total) VALUES (?,?,?,?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setInt(1, inv.getCustomerId());
            ps.setDate(2, Date.valueOf(inv.getInvoiceDate()));
            ps.setString(3, inv.getBillingCountry());
            ps.setBigDecimal(4, inv.getTotal());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    @Override
    public boolean update(Invoice inv) {
        String sql = "UPDATE Invoice SET CustomerId=?,InvoiceDate=?,BillingCountry=?,Total=? WHERE InvoiceId=?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setInt(1, inv.getCustomerId());
            ps.setDate(2, Date.valueOf(inv.getInvoiceDate()));
            ps.setString(3, inv.getBillingCountry());
            ps.setBigDecimal(4, inv.getTotal());
            ps.setInt(5, inv.getInvoiceId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    @Override
    public boolean delete(int id) {
        String sql = "DELETE FROM Invoice WHERE InvoiceId = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public List<Invoice> findByDateRange(LocalDate from, LocalDate to) {
        List<Invoice> list = new ArrayList<>();
        String sql = "SELECT * FROM Invoice WHERE InvoiceDate BETWEEN ? AND ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(from));
            ps.setDate(2, Date.valueOf(to));
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public Map<String, Double> revenueByCountry() {
        Map<String, Double> map = new LinkedHashMap<>();
        String sql = "SELECT BillingCountry, SUM(Total) as rev FROM Invoice GROUP BY BillingCountry ORDER BY rev DESC LIMIT 10";
        try (Statement st = getConnection().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) map.put(rs.getString("BillingCountry"), rs.getDouble("rev"));
        } catch (SQLException e) { e.printStackTrace(); }
        return map;
    }

    public Map<String, Double> revenueByYear() {
        Map<String, Double> map = new LinkedHashMap<>();
        String sql = "SELECT YEAR(InvoiceDate) as yr, SUM(Total) as rev FROM Invoice GROUP BY yr ORDER BY yr";
        try (Statement st = getConnection().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) map.put(String.valueOf(rs.getInt("yr")), rs.getDouble("rev"));
        } catch (SQLException e) { e.printStackTrace(); }
        return map;
    }
}