package com.chinook.dao;

import com.chinook.model.Artist;
import java.sql.*;
import java.util.*;

public class ArtistDAO extends AbstractDAO implements BaseDAO<Artist> {

    @Override
    public Optional<Artist> findById(int id) {
        String sql = "SELECT * FROM Artist WHERE ArtistId = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return Optional.of(new Artist(rs.getInt("ArtistId"), rs.getString("Name")));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return Optional.empty();
    }

    @Override
    public List<Artist> findAll() {
        List<Artist> list = new ArrayList<>();
        String sql = "SELECT * FROM Artist ORDER BY Name";
        try (Statement st = getConnection().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new Artist(rs.getInt("ArtistId"), rs.getString("Name")));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    @Override
    public List<Artist> findAll(int page, int pageSize) {
        List<Artist> list = new ArrayList<>();
        String sql = "SELECT * FROM Artist ORDER BY Name LIMIT ? OFFSET ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setInt(1, pageSize);
            ps.setInt(2, (page - 1) * pageSize);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Artist(rs.getInt("ArtistId"), rs.getString("Name")));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    @Override
    public boolean save(Artist artist) {
        String sql = "INSERT INTO Artist (Name) VALUES (?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setString(1, artist.getName());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    @Override
    public boolean update(Artist artist) {
        String sql = "UPDATE Artist SET Name = ? WHERE ArtistId = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setString(1, artist.getName());
            ps.setInt(2, artist.getArtistId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    @Override
    public boolean delete(int id) {
        String sql = "DELETE FROM Artist WHERE ArtistId = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public List<Artist> search(String keyword) {
        List<Artist> list = new ArrayList<>();
        String sql = "SELECT * FROM Artist WHERE Name LIKE ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setString(1, "%" + keyword + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Artist(rs.getInt("ArtistId"), rs.getString("Name")));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }
}