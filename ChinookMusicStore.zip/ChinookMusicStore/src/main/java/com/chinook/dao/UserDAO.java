package com.chinook.dao;

import com.chinook.model.User;
import com.chinook.util.PasswordUtil;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.*;

public class UserDAO extends AbstractDAO implements BaseDAO<User> {

    public Optional<User> findByUsername(String username) {
        String sql = "SELECT * FROM users WHERE username = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                User user = new User();              
                user.setUserId(rs.getInt("user_id"));
                user.setUsername(rs.getString("username"));
                user.setPasswordHash(rs.getString("password_hash"));
                user.setRole(rs.getString("role"));
                user.setFullName(rs.getString("full_name"));
                Timestamp ts = rs.getTimestamp("last_login");
                if (ts != null) user.setLastLogin(ts.toLocalDateTime());
                return Optional.of(user);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return Optional.empty();
    }

    public boolean authenticate(String username, String plainPassword) {
        return findByUsername(username)
            .map(u -> PasswordUtil.verify(plainPassword, u.getPasswordHash().trim()))
            .orElse(false);
    }

    public void updateLastLogin(String username) {
        String sql = "UPDATE users SET last_login = ? WHERE username = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setTimestamp(1, Timestamp.valueOf(LocalDateTime.now()));
            ps.setString(2, username);
            ps.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    @Override public Optional<User> findById(int id) { return Optional.empty(); }
    @Override public List<User> findAll() { return Collections.emptyList(); }
    @Override public List<User> findAll(int page, int pageSize) { return Collections.emptyList(); }
    @Override public boolean save(User u) { return false; }
    @Override public boolean update(User u) { return false; }
    @Override public boolean delete(int id) { return false; }
}