package com.chinook.view;

import com.chinook.controller.RoleGuard;
import com.chinook.dao.DAOFactory;
import com.chinook.model.Invoice;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.time.LocalDate;

public class InvoicePanel extends JPanel {

    private static final long serialVersionUID = 1L;
    private JTable table;
    private DefaultTableModel model;

    public InvoicePanel() {
        buildUI();
        load();
    }

    private void buildUI() {
        setLayout(new BorderLayout(5, 5));
        model = new DefaultTableModel(
            new String[]{"ID", "Customer ID", "Date", "Country", "Total"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);

        JButton btnAdd    = new JButton("Add");
        JButton btnDelete = new JButton("Delete");
        RoleGuard.applyTo(btnAdd);
        RoleGuard.applyTo(btnDelete);
        JPanel btns = new JPanel();
        btns.add(btnAdd); btns.add(btnDelete);
        btnAdd.addActionListener(e -> addInvoice());
        btnDelete.addActionListener(e -> deleteInvoice());

        add(new JScrollPane(table), BorderLayout.CENTER);
        add(btns, BorderLayout.SOUTH);
    }

    private void load() {
        model.setRowCount(0);
        DAOFactory.createInvoiceDAO().findAll()
            .forEach(inv -> model.addRow(new Object[]{
                inv.getInvoiceId(), inv.getCustomerId(),
                inv.getInvoiceDate(), inv.getBillingCountry(), inv.getTotal()
            }));
    }

    private void addInvoice() {
        JTextField fCustId  = new JTextField();
        JTextField fDate    = new JTextField(LocalDate.now().toString());
        JTextField fCountry = new JTextField();
        JTextField fTotal   = new JTextField();
        Object[] fields = {"Customer ID:", fCustId, "Date (yyyy-mm-dd):", fDate,
                           "Country:", fCountry, "Total:", fTotal};
        int r = JOptionPane.showConfirmDialog(this, fields, "Add Invoice", JOptionPane.OK_CANCEL_OPTION);
        if (r != JOptionPane.OK_OPTION) return;
        try {
            Invoice inv = new Invoice(0,
                Integer.parseInt(fCustId.getText().trim()),
                LocalDate.parse(fDate.getText().trim()),
                fCountry.getText().trim(),
                new BigDecimal(fTotal.getText().trim()));
            if (DAOFactory.createInvoiceDAO().save(inv)) load();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid input: " + ex.getMessage());
        }
    }

    private void deleteInvoice() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        int id = (int) model.getValueAt(row, 0);
        if (JOptionPane.showConfirmDialog(this, "Delete?") == JOptionPane.YES_OPTION) {
            DAOFactory.createInvoiceDAO().delete(id);
            load();
        }
    }
}