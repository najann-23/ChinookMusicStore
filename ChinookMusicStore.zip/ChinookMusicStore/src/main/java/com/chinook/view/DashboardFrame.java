package com.chinook.view;

import com.chinook.controller.RoleGuard;
import com.chinook.util.ChartFactory;
import com.chinook.util.DatabaseConnection;

import javax.swing.*;
import java.awt.*;
import java.sql.ResultSet;
import java.sql.Statement;

public class DashboardFrame extends JFrame {

    public DashboardFrame() {
        buildUI();
    }

    private void buildUI() {
        setTitle("Chinook Music Store — Dashboard ["
            + RoleGuard.getCurrentUser().getRole() + "]");
        setSize(1100, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane(); // đổi var → JTabbedPane
        tabs.addTab("Dashboard", buildDashboardPanel());
        tabs.addTab("Artists",   new ArtistPanel());
        tabs.addTab("Albums",    new AlbumPanel());
        tabs.addTab("Customers", new CustomerPanel());
        tabs.addTab("Invoices",  new InvoicePanel());

        if (RoleGuard.isAdmin()) {
            tabs.addTab("Users", new UserPanel());
        }

        JButton btnLogout = new JButton("Logout"); // đổi var → JButton
        btnLogout.addActionListener(e -> {
            RoleGuard.setCurrentUser(null);
            dispose();
            new LoginFrame();
        });

        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.RIGHT)); // đổi var → JPanel
        topBar.add(new JLabel("Welcome, " + RoleGuard.getCurrentUser().getFullName()));
        topBar.add(btnLogout);

        add(topBar, BorderLayout.NORTH);
        add(tabs, BorderLayout.CENTER);
        setVisible(true);
    }

    private JPanel buildDashboardPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        JPanel kpiPanel = new JPanel(new GridLayout(1, 4, 10, 10));
        kpiPanel.setBorder(BorderFactory.createTitledBorder("Key Metrics"));
        kpiPanel.add(makeKPI("Total Artists",   getCount("SELECT COUNT(*) FROM Artist")));
        kpiPanel.add(makeKPI("Total Customers", getCount("SELECT COUNT(*) FROM Customer")));
        kpiPanel.add(makeKPI("Total Invoices",  getCount("SELECT COUNT(*) FROM Invoice")));
        kpiPanel.add(makeKPI("Total Revenue",   "$" + getSum("SELECT SUM(Total) FROM Invoice")));

        JPanel chartPanel = new JPanel(new GridLayout(1, 2, 10, 10));
        chartPanel.add(ChartFactory.createRevenueBarChart());
        chartPanel.add(ChartFactory.createTopCountryPieChart());

        panel.add(kpiPanel, BorderLayout.NORTH);
        panel.add(chartPanel, BorderLayout.CENTER);
        return panel;
    }

    private JLabel makeKPI(String label, String value) {
        JLabel lbl = new JLabel(
            "<html><center>" + label + "<br><b>" + value + "</b></center></html>",
            SwingConstants.CENTER);
        lbl.setFont(new Font("Arial", Font.PLAIN, 14));
        lbl.setBorder(BorderFactory.createEtchedBorder());
        return lbl;
    }

    private String getCount(String sql) {
        try (Statement st = DatabaseConnection.getInstance().getConnection().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            if (rs.next()) return String.valueOf(rs.getInt(1));
        } catch (Exception e) { e.printStackTrace(); }
        return "N/A";
    }

    private String getSum(String sql) {
        try (Statement st = DatabaseConnection.getInstance().getConnection().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            if (rs.next()) return String.format("%.2f", rs.getDouble(1));
        } catch (Exception e) { e.printStackTrace(); }
        return "N/A";
    }
}