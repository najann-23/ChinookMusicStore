package com.chinook.view;

import com.chinook.controller.RoleGuard;
import com.chinook.dao.DAOFactory;
import com.chinook.model.Album;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class AlbumPanel extends JPanel {

    private static final long serialVersionUID = 1L;
    private JTable table;
    private DefaultTableModel model;
    private JTextField txtSearch;

    public AlbumPanel() {
        buildUI();
        load();
    }

    private void buildUI() {
        setLayout(new BorderLayout(5, 5));
        txtSearch = new JTextField(20);
        JButton btnSearch = new JButton("Search");
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(new JLabel("Search:")); top.add(txtSearch); top.add(btnSearch);
        btnSearch.addActionListener(e -> search());

        model = new DefaultTableModel(new String[]{"ID", "Title", "Artist ID"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);

        JButton btnAdd    = new JButton("Add");
        JButton btnEdit   = new JButton("Edit");
        JButton btnDelete = new JButton("Delete");
        RoleGuard.applyTo(btnAdd);
        RoleGuard.applyTo(btnEdit);
        RoleGuard.applyTo(btnDelete);

        JPanel btns = new JPanel();
        btns.add(btnAdd); btns.add(btnEdit); btns.add(btnDelete);

        btnAdd.addActionListener(e -> addAlbum());
        btnEdit.addActionListener(e -> editAlbum());
        btnDelete.addActionListener(e -> deleteAlbum());

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(btns, BorderLayout.SOUTH);
    }

    private void load() {
        model.setRowCount(0);
        DAOFactory.createAlbumDAO().findAll()
            .forEach(a -> model.addRow(new Object[]{a.getAlbumId(), a.getTitle(), a.getArtistId()}));
    }

    private void search() {
        String kw = txtSearch.getText().trim();
        model.setRowCount(0);
        DAOFactory.createAlbumDAO().findAll().stream()
            .filter(a -> a.getTitle().toLowerCase().contains(kw.toLowerCase()))
            .forEach(a -> model.addRow(new Object[]{a.getAlbumId(), a.getTitle(), a.getArtistId()}));
    }

    private void addAlbum() {
        JTextField fTitle    = new JTextField();
        JTextField fArtistId = new JTextField();
        Object[] fields = {"Title:", fTitle, "Artist ID:", fArtistId};
        int r = JOptionPane.showConfirmDialog(this, fields, "Add Album", JOptionPane.OK_CANCEL_OPTION);
        if (r != JOptionPane.OK_OPTION) return;
        try {
            Album a = new Album(0, fTitle.getText().trim(), Integer.parseInt(fArtistId.getText().trim()));
            if (DAOFactory.createAlbumDAO().save(a)) load();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Artist ID must be a number.");
        }
    }

    private void editAlbum() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        int id = (int) model.getValueAt(row, 0);
        DAOFactory.createAlbumDAO().findById(id).ifPresent(a -> {
            JTextField fTitle    = new JTextField(a.getTitle());
            JTextField fArtistId = new JTextField(String.valueOf(a.getArtistId()));
            Object[] fields = {"Title:", fTitle, "Artist ID:", fArtistId};
            int r = JOptionPane.showConfirmDialog(this, fields, "Edit Album", JOptionPane.OK_CANCEL_OPTION);
            if (r != JOptionPane.OK_OPTION) return;
            a.setTitle(fTitle.getText().trim());
            try { a.setArtistId(Integer.parseInt(fArtistId.getText().trim())); } catch (Exception ex) {}
            DAOFactory.createAlbumDAO().update(a);
            load();
        });
    }

    private void deleteAlbum() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        int id = (int) model.getValueAt(row, 0);
        if (JOptionPane.showConfirmDialog(this, "Delete?") == JOptionPane.YES_OPTION) {
            DAOFactory.createAlbumDAO().delete(id);
            load();
        }
    }
}