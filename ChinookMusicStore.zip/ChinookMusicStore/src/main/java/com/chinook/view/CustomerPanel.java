package com.chinook.view;

import com.chinook.controller.RoleGuard;
import com.chinook.dao.DAOFactory;
import com.chinook.model.Customer;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class CustomerPanel extends JPanel {

    private JTable table;
    private DefaultTableModel model;
    private JTextField txtSearch;

    public CustomerPanel() {
        buildUI();
        load();
    }

    private void buildUI() {
        setLayout(new BorderLayout(5, 5));

        txtSearch = new JTextField(20);
        var btnSearch = new JButton("Search");
        var top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(new JLabel("Search:")); top.add(txtSearch); top.add(btnSearch);
        btnSearch.addActionListener(e -> search());

        model = new DefaultTableModel(
            new String[]{"ID","First Name","Last Name","Email","Country"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);

        var btnAdd    = new JButton("Add");
        var btnEdit   = new JButton("Edit");
        var btnDelete = new JButton("Delete");
        RoleGuard.applyTo(btnAdd);
        RoleGuard.applyTo(btnEdit);
        RoleGuard.applyTo(btnDelete);

        var btns = new JPanel();
        btns.add(btnAdd); btns.add(btnEdit); btns.add(btnDelete);

        btnAdd.addActionListener(e -> addCustomer());
        btnEdit.addActionListener(e -> editCustomer());
        btnDelete.addActionListener(e -> deleteCustomer());

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(btns, BorderLayout.SOUTH);
    }

    private void load() {
        model.setRowCount(0);
        DAOFactory.createCustomerDAO().findAll()
            .forEach(c -> model.addRow(
                new Object[]{c.getCustomerId(), c.getFirstName(),
                             c.getLastName(), c.getEmail(), c.getCountry()}));
    }

    private void search() {
        String kw = txtSearch.getText().trim();
        model.setRowCount(0);
        var list = kw.isEmpty()
            ? DAOFactory.createCustomerDAO().findAll()
            : DAOFactory.createCustomerDAO().search(kw);
        list.forEach(c -> model.addRow(
            new Object[]{c.getCustomerId(), c.getFirstName(),
                         c.getLastName(), c.getEmail(), c.getCountry()}));
    }

    private void addCustomer() {
        JTextField fFirst = new JTextField(), fLast = new JTextField(),
                   fEmail = new JTextField(), fCountry = new JTextField();
        Object[] fields = {"First Name:", fFirst, "Last Name:", fLast,
                           "Email:", fEmail, "Country:", fCountry};
        int r = JOptionPane.showConfirmDialog(this, fields, "Add Customer", JOptionPane.OK_CANCEL_OPTION);
        if (r != JOptionPane.OK_OPTION) return;
        var c = new Customer(0, fFirst.getText().trim(), fLast.getText().trim(),
                               fEmail.getText().trim(), fCountry.getText().trim());
        if (DAOFactory.createCustomerDAO().save(c)) { load(); }
    }

    private void editCustomer() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        int id = (int) model.getValueAt(row, 0);
        DAOFactory.createCustomerDAO().findById(id).ifPresent(c -> {
            JTextField fFirst   = new JTextField(c.getFirstName()),
                       fLast    = new JTextField(c.getLastName()),
                       fEmail   = new JTextField(c.getEmail()),
                       fCountry = new JTextField(c.getCountry());
            Object[] fields = {"First Name:", fFirst, "Last Name:", fLast,
                               "Email:", fEmail, "Country:", fCountry};
            int r = JOptionPane.showConfirmDialog(this, fields, "Edit Customer", JOptionPane.OK_CANCEL_OPTION);
            if (r != JOptionPane.OK_OPTION) return;
            c.setFirstName(fFirst.getText().trim());
            c.setLastName(fLast.getText().trim());
            c.setEmail(fEmail.getText().trim());
            c.setCountry(fCountry.getText().trim());
            DAOFactory.createCustomerDAO().update(c);
            load();
        });
    }

    private void deleteCustomer() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        int id = (int) model.getValueAt(row, 0);
        if (JOptionPane.showConfirmDialog(this, "Delete?") == JOptionPane.YES_OPTION) {
            DAOFactory.createCustomerDAO().delete(id);
            load();
        }
    }
}