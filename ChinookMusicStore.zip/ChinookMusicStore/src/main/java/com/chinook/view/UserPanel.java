package com.chinook.view;

import com.chinook.dao.DAOFactory;
import com.chinook.model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class UserPanel extends JPanel {

    private DefaultTableModel model;

    public UserPanel() {
        setLayout(new BorderLayout());
        model = new DefaultTableModel(new String[]{"ID","Username","Role","Full Name","Last Login"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        var table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        try (var ps = com.chinook.util.DatabaseConnection.getInstance()
                .getConnection().prepareStatement("SELECT * FROM users");
             var rs = ps.executeQuery()) {
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("user_id"),
                    rs.getString("username"),
                    rs.getString("role"),
                    rs.getString("full_name"),
                    rs.getTimestamp("last_login")
                });
            }
        } catch (Exception e) { e.printStackTrace(); }
    }
}