package com.chinook.view;

import com.chinook.controller.RoleGuard;
import com.chinook.dao.DAOFactory;
import com.chinook.event.DataChangeEvent;
import com.chinook.model.Artist;
import com.chinook.util.ExportUtil;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ArtistPanel extends JPanel {

    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField txtSearch;
    private List<Artist> currentData;

    public ArtistPanel() {
        buildUI();
        loadData();
    }

    private void buildUI() {
        setLayout(new BorderLayout(5, 5));

        var topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        txtSearch = new JTextField(20);
        var btnSearch = new JButton("Search");
        topPanel.add(new JLabel("Search:"));
        topPanel.add(txtSearch);
        topPanel.add(btnSearch);
        btnSearch.addActionListener(e -> searchData());

        tableModel = new DefaultTableModel(new String[]{"ID", "Name"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        var btnPanel = new JPanel(new FlowLayout());
        var btnAdd    = new JButton("Add");
        var btnEdit   = new JButton("Edit");
        var btnDelete = new JButton("Delete");
        var btnExport = new JButton("Export Excel");

        RoleGuard.applyTo(btnAdd);
        RoleGuard.applyTo(btnEdit);
        RoleGuard.applyTo(btnDelete);

        btnPanel.add(btnAdd);
        btnPanel.add(btnEdit);
        btnPanel.add(btnDelete);
        btnPanel.add(btnExport);

        btnAdd.addActionListener(e -> showAddDialog());
        btnEdit.addActionListener(e -> showEditDialog());
        btnDelete.addActionListener(e -> deleteSelected());
        btnExport.addActionListener(e -> exportExcel());

        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(btnPanel, BorderLayout.SOUTH);
    }

    private void loadData() {
        currentData = DAOFactory.createArtistDAO().findAll();
        refreshTable(currentData);
    }

    private void refreshTable(List<Artist> data) {
        tableModel.setRowCount(0);
        data.forEach(a -> tableModel.addRow(new Object[]{a.getArtistId(), a.getName()}));
    }

    private void searchData() {
        String kw = txtSearch.getText().trim();
        if (kw.isEmpty()) { loadData(); return; }
        refreshTable(DAOFactory.createArtistDAO().search(kw));
    }

    private void showAddDialog() {
        String name = JOptionPane.showInputDialog(this, "Artist Name:");
        if (name == null || name.trim().isEmpty()) return;
        var artist = new Artist(0, name.trim());
        if (DAOFactory.createArtistDAO().save(artist)) {
            loadData();
            DataChangeEvent.fire(); // Notify charts
            JOptionPane.showMessageDialog(this, "Artist added!");
        }
    }

    private void showEditDialog() {
        int row = table.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Select a row first."); return; }
        int id = (int) tableModel.getValueAt(row, 0);
        String current = (String) tableModel.getValueAt(row, 1);
        String name = (String) JOptionPane.showInputDialog(this,
            "Edit Name:", "Edit Artist", JOptionPane.PLAIN_MESSAGE, null, null, current);
        if (name == null || name.trim().isEmpty()) return;
        if (DAOFactory.createArtistDAO().update(new Artist(id, name.trim()))) {
            loadData();
            DataChangeEvent.fire();
        }
    }

    private void deleteSelected() {
        int row = table.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Select a row first."); return; }
        int id = (int) tableModel.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this, "Delete this artist?");
        if (confirm == JOptionPane.YES_OPTION) {
            DAOFactory.createArtistDAO().delete(id);
            loadData();
            DataChangeEvent.fire();
        }
    }

    private void exportExcel() {
        ExportUtil.exportArtists(currentData);
        JOptionPane.showMessageDialog(this, "Exported to artists_export.xlsx");
    }
}