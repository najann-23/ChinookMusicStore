package com.chinook.view;

import com.chinook.dao.UserDAO;
import com.chinook.dao.DAOFactory;
import com.chinook.controller.RoleGuard;
import com.chinook.model.User;
import com.chinook.util.DatabaseInitializer;

import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {

    private JTextField txtUsername;
    private JPasswordField txtPassword;

    public LoginFrame() {
        DatabaseInitializer.init();
        buildUI();
    }

    private void buildUI() {
        setTitle("Chinook Music Store — Login");
        setSize(400, 250);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints(); // đổi var → GridBagConstraints
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("Chinook Music Store", SwingConstants.CENTER); // bỏ emoji
        title.setFont(new Font("Arial", Font.BOLD, 18));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        panel.add(title, gbc);

        gbc.gridwidth = 1; gbc.gridy = 1; gbc.gridx = 0;
        panel.add(new JLabel("Username:"), gbc);
        txtUsername = new JTextField(15);
        gbc.gridx = 1;
        panel.add(txtUsername, gbc);

        gbc.gridy = 2; gbc.gridx = 0;
        panel.add(new JLabel("Password:"), gbc);
        txtPassword = new JPasswordField(15);
        gbc.gridx = 1;
        panel.add(txtPassword, gbc);

        JButton btnLogin = new JButton("Login"); // đổi var → JButton
        gbc.gridy = 3; gbc.gridx = 0; gbc.gridwidth = 2;
        panel.add(btnLogin, gbc);

        btnLogin.addActionListener(e -> doLogin());
        txtPassword.addActionListener(e -> doLogin());

        add(panel);
        setVisible(true);
    }

    private void doLogin() {
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields.",
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        UserDAO userDAO = DAOFactory.createUserDAO(); // đổi var → UserDAO
        if (userDAO.authenticate(username, password)) {
            User user = userDAO.findByUsername(username).get();
            userDAO.updateLastLogin(username);
            RoleGuard.setCurrentUser(user);
            dispose();
            new DashboardFrame();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid username or password.",
                "Login Failed", JOptionPane.ERROR_MESSAGE);
            txtPassword.setText("");
        }
    }
}