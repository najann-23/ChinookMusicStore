package com.chinook.sort;

import java.util.Comparator;

public interface SortStrategy<T> {
    Comparator<T> getComparator();
}