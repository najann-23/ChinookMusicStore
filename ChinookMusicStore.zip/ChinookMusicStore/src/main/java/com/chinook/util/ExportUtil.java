package com.chinook.util;

import com.chinook.model.Artist;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.util.List;

public class ExportUtil {

    public static void exportArtists(List<Artist> artists) {
        try (Workbook wb = new XSSFWorkbook()) {
            Sheet sheet = wb.createSheet("Artists");

            // Header row
            Row header = sheet.createRow(0);
            CellStyle headerStyle = wb.createCellStyle();
            Font font = wb.createFont();
            font.setBold(true);
            headerStyle.setFont(font);

            String[] cols = {"Artist ID", "Name"};
            for (int i = 0; i < cols.length; i++) {
                Cell cell = header.createCell(i);
                cell.setCellValue(cols[i]);
                cell.setCellStyle(headerStyle);
            }

            int rowNum = 1;
            for (Artist a : artists) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(a.getArtistId());
                row.createCell(1).setCellValue(a.getName());
            }

            Row summary = sheet.createRow(rowNum);
            summary.createCell(0).setCellValue("Total:");
            summary.createCell(1).setCellValue(artists.size());

            sheet.autoSizeColumn(0);
            sheet.autoSizeColumn(1);

            try (FileOutputStream fos = new FileOutputStream("artists_export.xlsx")) {
                wb.write(fos);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}