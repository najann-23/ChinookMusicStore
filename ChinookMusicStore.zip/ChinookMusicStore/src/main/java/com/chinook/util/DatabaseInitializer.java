package com.chinook.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DatabaseInitializer {

    public static void init() {
        try {
            Connection conn = DatabaseConnection.getInstance().getConnection();

            String check = "SELECT password_hash FROM users WHERE username = 'admin'";
            PreparedStatement ps = conn.prepareStatement(check);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String hash = rs.getString("password_hash");
                if ("PLACEHOLDER".equals(hash)) {
                    updatePassword(conn, "admin", "admin123");
                    updatePassword(conn, "viewer", "viewer123");
                    System.out.println("Passwords initialized.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void updatePassword(Connection conn, String username, String plain)
            throws Exception {
        String sql = "UPDATE users SET password_hash = ? WHERE username = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, PasswordUtil.hash(plain));
        ps.setString(2, username);
        ps.executeUpdate();
    }
}