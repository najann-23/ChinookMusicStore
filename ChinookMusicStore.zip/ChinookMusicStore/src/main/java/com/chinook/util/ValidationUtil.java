package com.chinook.util;

public class ValidationUtil {

    public static boolean isNullOrEmpty(String s) {
        return s == null || s.trim().isEmpty();
    }

    public static boolean isValidEmail(String email) {
        if (isNullOrEmpty(email)) return false;
        return email.matches("^[\\w._%+\\-]+@[\\w.\\-]+\\.[a-zA-Z]{2,}$");
    }

    public static boolean isPositive(double value) {
        return value > 0;
    }

    public static boolean isPositiveInt(int value) {
        return value > 0;
    }
}