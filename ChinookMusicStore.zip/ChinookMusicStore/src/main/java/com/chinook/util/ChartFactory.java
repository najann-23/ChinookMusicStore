package com.chinook.util;

import com.chinook.dao.DAOFactory;
import com.chinook.dao.InvoiceDAO;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

import javax.swing.*;
import java.util.Map;

public class ChartFactory {

    public static JPanel createRevenueBarChart() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset(); // đổi var
        InvoiceDAO invoiceDAO = DAOFactory.createInvoiceDAO();         // đổi var
        invoiceDAO.revenueByYear()
            .forEach((year, rev) -> dataset.addValue(rev, "Revenue", year));

        JFreeChart chart = org.jfree.chart.ChartFactory.createBarChart(
            "Revenue by Year", "Year", "Revenue (USD)",
            dataset, PlotOrientation.VERTICAL, false, true, false);

        return new ChartPanel(chart);
    }

    public static JPanel createTopCountryPieChart() {
        DefaultPieDataset dataset = new DefaultPieDataset(); // đổi var, bỏ generic
        InvoiceDAO invoiceDAO = DAOFactory.createInvoiceDAO();
        Map<String, Double> data = invoiceDAO.revenueByCountry();

        data.entrySet().stream()
            .limit(5)
            .forEach(e -> dataset.setValue(e.getKey(), e.getValue()));

        JFreeChart chart = org.jfree.chart.ChartFactory.createPieChart(
            "Top 5 Countries by Revenue", dataset, true, true, false);

        return new ChartPanel(chart);
    }
}