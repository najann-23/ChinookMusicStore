package com.chinook.util;

import org.mindrot.jbcrypt.BCrypt;

public class PasswordUtil {

    public static String hash(String plainPassword) {
        return BCrypt.hashpw(plainPassword, BCrypt.gensalt(12));
    }
    
    public static boolean verify(String plaintextPassword, String hashedPassword) {
        if (hashedPassword == null) {
            return false;
        }
        return BCrypt.checkpw(plaintextPassword, hashedPassword.trim());
    }
}