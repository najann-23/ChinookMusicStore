package com.chinook.event;

public interface DataChangeListener {
    void onDataChanged(); 
}