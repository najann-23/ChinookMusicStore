package com.chinook.event;

import java.util.ArrayList;
import java.util.List;

public class DataChangeEvent {
    private static final List<DataChangeListener> listeners = new ArrayList<>();

    public static void addListener(DataChangeListener l) { listeners.add(l); }
    public static void fire() { listeners.forEach(DataChangeListener::onDataChanged); }
}