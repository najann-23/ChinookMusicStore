import com.chinook.view.LoginFrame;
import javax.swing.SwingUtilities;

import org.mindrot.jbcrypt.BCrypt;

public class Main {
    public static void main(String[] args) {
    	System.out.println(BCrypt.hashpw("admin123", BCrypt.gensalt(12)));
    	System.out.println(BCrypt.hashpw("viewer123", BCrypt.gensalt(12)));
    			SwingUtilities.invokeLater(LoginFrame::new);
    }
}